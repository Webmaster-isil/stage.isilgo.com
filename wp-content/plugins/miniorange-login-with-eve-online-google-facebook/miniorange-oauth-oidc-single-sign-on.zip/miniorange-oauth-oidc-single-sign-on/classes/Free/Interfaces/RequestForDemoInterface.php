<?php


namespace MoOauthClient\Free;

interface RequestForDemoInterface
{
    function render_free_ui();
}
