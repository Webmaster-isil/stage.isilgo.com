<?php


namespace MoOauthClient\Free;

interface CustomizationInterface
{
    function render_free_ui();
}
