<?php


class MoOAuthConstants
{
    const PANEL_MESSAGE_OPTION = "\155\145\x73\163\x61\x67\145";
    const OPTION = "\x6f\x70\164\x69\x6f\156";
    const POST_APP_NAME = "\155\157\x5f\157\141\x75\164\150\137\141\x70\x70\137\x6e\x61\x6d\145";
    const MAP_KEY = "\x6d\141\160\x70\x69\x6e\147\137\x6b\145\171\x5f";
    const EMAIL = "\x65\155\x61\151\x6c";
}
