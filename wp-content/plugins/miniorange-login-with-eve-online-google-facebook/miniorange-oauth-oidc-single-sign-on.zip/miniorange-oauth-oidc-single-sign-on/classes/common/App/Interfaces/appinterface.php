<?php


namespace MoOauthClient\App;

interface AppInterface
{
    public function get_app_config($sf);
    public function update_app_config($HH, $W7);
}
