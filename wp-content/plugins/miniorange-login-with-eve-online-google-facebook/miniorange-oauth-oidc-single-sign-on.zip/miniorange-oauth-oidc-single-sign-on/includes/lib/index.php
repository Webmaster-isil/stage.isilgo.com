<?php


if (defined("\x57\120\x49\116\103")) {
    goto v0g;
}
die;
v0g:
