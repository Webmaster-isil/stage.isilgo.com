<?php


include "MoOAuthClientBasicEnum.php";
class mo_oauth_client_options_plugin_constants extends MoOAuthClientBasicEnum
{
    const CMS_Name = "\x57\x50";
    const Application_Name = "\127\120\40\x6d\151\156\151\117\x72\141\x6e\x67\x65\40\117\x41\165\x74\x68\40\x53\123\117\40\120\x6c\x75\147\x69\156";
    const Application_type = "\x4f\101\x55\x54\x48";
    const Version = "\x32\x38\56\65\x2e\x30";
    const HOSTNAME = "\x68\x74\164\x70\163\72\57\x2f\154\157\147\x69\156\56\170\145\x63\x75\x72\x69\x66\171\56\x63\157\155";
    const LICENSE_TYPE = "\x57\x50\137\x4f\x41\x55\124\110\x5f\x43\x4c\111\105\116\124\x5f\x50\114\125\107\111\116";
    const LICENSE_PLAN_NAME = "\167\160\x5f\157\x61\165\164\150\137\143\154\151\145\x6e\164\x5f\x70\162\145\155\x69\x75\155\137\x70\154\141\156";
}
